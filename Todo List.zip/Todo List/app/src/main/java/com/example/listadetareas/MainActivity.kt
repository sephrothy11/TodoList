package com.example.listadetareas

import TodoItems.TodoDB
import TodoItems.TodoItemData
import TodoItems.TodoListAdapter
import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import helpers.ActivitiesHelper
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    //Variables
    var allItems:MutableList<TodoItemData> = ArrayList()
    var adapter:TodoListAdapter? = null
    var todoDBController:TodoDB.Controller? = null
    //Funcion crear
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        todoDBController = TodoDB.Controller(this)


        this.setTitle("Lista de Tareas")
        Agregar.setOnClickListener {
            startActivityForResult(ActivitiesHelper().openAddTodo(this), ActivitiesHelper().openAddTodoRID)
        }
        getTodos()
        initTodoRecycler()
    }
    //Funcion Resultado Act
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if(resultCode == Activity.RESULT_OK)
        {
            getTodos()
            initTodoRecycler()
            adapter?.notifyDataSetChanged()
            super.onActivityResult(requestCode, resultCode, data)
        }else {

        }
    }
    //Funcion Editar
    fun editar(item: TodoItemData){
        startActivityForResult(ActivitiesHelper().openEditTodo(this, item), ActivitiesHelper().openEditTodoRID)
    }
    //Fucion borrar
    fun delete(item: TodoItemData) {
        todoDBController!!.delete(item)
        getTodos()
        initTodoRecycler()
    }
    //Funcion get para el Todos
    fun getTodos() {
        allItems = todoDBController!!.getTodo()
    }
    //Recycler
    fun initTodoRecycler() {
        adapter = TodoListAdapter(allItems, this, ::editar, ::delete)
        Lista.layoutManager = LinearLayoutManager(this)
        Lista.adapter =  adapter
    }
}