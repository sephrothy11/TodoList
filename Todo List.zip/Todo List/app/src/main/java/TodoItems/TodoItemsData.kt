package TodoItems

data class TodoItemData(var id:Int, var tittle:String, var message:String, var date:String, var image:String)
